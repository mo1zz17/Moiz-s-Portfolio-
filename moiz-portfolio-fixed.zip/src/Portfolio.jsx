import React from "react";
import { Github, Linkedin, Twitter } from "lucide-react";

export default function Portfolio() {
  return (
    <main className="min-h-screen bg-[#0d0d0d] text-white font-sans px-6 py-12">
      <section className="max-w-4xl mx-auto text-center space-y-6">
        <h1 className="text-4xl font-bold">Hi, I'm Abdul Moiz</h1>
        <h2 className="text-xl text-gray-400">
          Front End Developer / WordPress Developer
        </h2>
        <p className="text-gray-300 max-w-2xl mx-auto">
          I’m a passionate Front End and WordPress Developer focused on building
          visually engaging and technically sound websites. With a love for
          pixel-perfect design and efficient code, I turn ideas into digital
          reality. Currently working on a cutting-edge DeFi tool to reshape
          market tracking.
        </p>
        <div className="flex justify-center gap-4">
          <a href="https://github.com/mo1zz17" target="_blank">
            <Github className="w-6 h-6 hover:text-blue-400" />
          </a>
          <a
            href="https://www.linkedin.com/in/abdul-moiz-542696267"
            target="_blank"
          >
            <Linkedin className="w-6 h-6 hover:text-blue-400" />
          </a>
          <a href="https://x.com/mo1zz17" target="_blank">
            <Twitter className="w-6 h-6 hover:text-blue-400" />
          </a>
        </div>
      </section>

      <section className="max-w-4xl mx-auto mt-16">
        <h3 className="text-2xl font-semibold mb-6">Projects</h3>
        <div className="bg-[#1a1a1a] text-white border border-gray-700 p-6 rounded-lg">
          <h4 className="text-xl font-semibold">The Dex Watch</h4>
          <p className="text-gray-400 mt-2">
            A powerful DEX analytics tool aimed to compete with Dex Screener.
            Currently in development, The Dex Watch focuses on lightning-fast
            token tracking, sleek UI, and real-time insights to empower
            traders like never before.
          </p>
          <span className="inline-block mt-4 text-xs text-yellow-500 uppercase">
            In Progress
          </span>
        </div>
      </section>

      <section className="max-w-4xl mx-auto mt-20 text-center">
        <h3 className="text-2xl font-semibold">Get in Touch</h3>
        <p className="text-gray-400 mt-2">moizsaleem944@gmail.com</p>
      </section>
    </main>
  );
}